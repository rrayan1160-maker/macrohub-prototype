const state = {
  history: ["splash"],
  goal: "Maintain",
  mealsPerDay: 3,
  selectedPlan: null,
  selectedMeal: null,
  customization: {},
};

const proteins = [
  { name: "صدر دجاج", proteinPer100g: 31, fatPer100g: 4 },
  { name: "لحم قليل الدهون", proteinPer100g: 27, fatPer100g: 9 },
  { name: "Kofta", proteinPer100g: 24, fatPer100g: 12 },
  { name: "Greek Yogurt Protein", proteinPer100g: 18, fatPer100g: 3 },
];

const carbs = [
  { name: "رز أبيض", carbs: 42, calories: 190 },
  { name: "رز بني", carbs: 38, calories: 180 },
  { name: "بطاطس", carbs: 34, calories: 155 },
  { name: "مكرونة", carbs: 46, calories: 220 },
];

const sauces = [
  { name: "صوص ريحان", calories: 45, carbs: 2, fat: 4 },
  { name: "ليمون وفلفل", calories: 35, carbs: 4, fat: 1 },
  { name: "سموكي BBQ", calories: 60, carbs: 8, fat: 2 },
  { name: "ترياكي", calories: 70, carbs: 12, fat: 1 },
  { name: "صوص مشروم", calories: 65, carbs: 5, fat: 4 },
  { name: "داود باشا طماطم", calories: 55, carbs: 7, fat: 2 },
  { name: "Honey Berry", calories: 50, carbs: 10, fat: 0 },
  { name: "Cinnamon Protein", calories: 40, carbs: 5, fat: 1 },
];

const meals = [
  meal("دجاج ريحان", 0, 0, ["Chicken breast", "Basil sauce", "Rice", "Zucchini"], ["#2DD4BF", "#0F766E"]),
  meal("دجاج ليمون وفلفل", 0, 2, ["Chicken breast", "Lemon pepper", "Potato", "Broccoli"], ["#FACC15", "#16A34A"]),
  meal("لحم سموكي", 1, 1, ["Lean beef", "Smoky BBQ sauce", "Brown rice", "Green beans"], ["#FB923C", "#7F1D1D"]),
  meal("كفتة داود باشا", 2, 0, ["Kofta", "Tomato sauce", "White rice", "Parsley"], ["#EF4444", "#7C2D12"]),
  meal("دجاج ترياكي", 0, 0, ["Chicken breast", "Teriyaki sauce", "Rice", "Sesame vegetables"], ["#38BDF8", "#1E3A8A"], 3),
  meal("دجاج مشروم", 0, 3, ["Chicken breast", "Mushroom sauce", "Pasta", "Spinach"], ["#A3E635", "#365314"], 4),
  meal("Greek Yogurt Bowl", 3, 1, ["Greek yogurt", "Granola", "Berries", "Honey drizzle"], ["#60A5FA", "#9333EA"], 6),
  meal("Protein Oats", 3, 3, ["Protein oats", "Greek yogurt", "Banana", "Cinnamon"], ["#FDE68A", "#92400E"], 7),
];

const goals = ["Lose Fat", "Maintain", "Build Muscle", "Custom Macros"];
const plans = [
  ["Balanced Plan", 899, "A complete mix of protein, clean carbs, and healthy fats."],
  ["High Protein Plan", 1049, "Higher protein meals for active routines and recovery."],
  ["Low Carb Plan", 969, "Lighter carb portions with high-satiety ingredients."],
  ["Custom Macros", 1199, "Macro targets tuned to your nutrition preferences."],
];

function meal(name, proteinIndex, carbIndex, ingredients, colors, sauceIndex = proteinIndex) {
  return { name, proteinIndex, carbIndex, sauceIndex, ingredients, colors };
}

function macrosFor(mealItem, custom = {}) {
  const protein = proteins[custom.proteinIndex ?? mealItem.proteinIndex];
  const carb = carbs[custom.carbIndex ?? mealItem.carbIndex];
  const sauce = sauces[custom.sauceIndex ?? mealItem.sauceIndex];
  const size = custom.size ?? 150;
  const multiplier = size / 100;
  const proteinGrams = Math.round(protein.proteinPer100g * multiplier);
  const proteinFat = Math.round(protein.fatPer100g * multiplier);
  return {
    calories: proteinGrams * 4 + proteinFat * 9 + carb.calories + sauce.calories + 55,
    protein: proteinGrams,
    carbs: carb.carbs + sauce.carbs + 8,
    fat: proteinFat + sauce.fat + 1,
  };
}

function route(id, push = true) {
  document.querySelectorAll(".screen").forEach((screen) => screen.classList.toggle("active", screen.id === id));
  if (push && state.history[state.history.length - 1] !== id) state.history.push(id);
  document.getElementById("bottomNav").classList.toggle("visible", ["home", "meals", "subscriptions", "profile"].includes(id));
  document.querySelectorAll(".bottom-nav button").forEach((button) => button.classList.toggle("active", button.dataset.tab === id));
  if (id === "plans") renderPlans();
  if (id === "meals") renderMeals();
  if (id === "home") renderHome();
  if (id === "checkout") renderCheckout();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function back() {
  state.history.pop();
  route(state.history[state.history.length - 1] || "splash", false);
}

function renderGoals() {
  const root = document.getElementById("goalOptions");
  root.innerHTML = goals.map((goal) => `<button class="option-card ${goal === state.goal ? "selected" : ""}" data-goal="${goal}"><strong>${goal}</strong><p class="muted">Personalized macros and meal rhythm.</p></button>`).join("");
}

function renderMealCounts() {
  const root = document.getElementById("mealCountOptions");
  root.innerHTML = [2, 3, 4, 5].map((count) => `<button class="meal-count ${count === state.mealsPerDay ? "selected" : ""}" data-count="${count}"><span>🍽</span><strong>${count} meals</strong></button>`).join("");
}

function renderPlans() {
  document.getElementById("planSubtitle").textContent = `${state.goal} - ${state.mealsPerDay} meals per day - billed monthly in SAR.`;
  document.getElementById("plansList").innerHTML = plans.map(([name, price, description], index) => `
    <button class="plan-card" data-plan="${index}">
      <div class="meal-title-row"><h3>${name}</h3><span class="pill">${price} SAR</span></div>
      <p class="muted">${description}</p>
      <p>${state.mealsPerDay} meals daily</p>
    </button>
  `).join("");
}

function mealCard(item, index) {
  const macro = macrosFor(item);
  return `
    <button class="meal-card" data-meal="${index}">
      <div class="meal-art" style="background:linear-gradient(135deg, ${item.colors[0]}, ${item.colors[1]})"><span>🍽</span></div>
      <div class="meal-title-row"><h3>${item.name}</h3><span class="pill">${macro.calories} kcal</span></div>
      <div class="macro-row">
        <div><span>Protein</span><strong>${macro.protein}g</strong></div>
        <div><span>Carbs</span><strong>${macro.carbs}g</strong></div>
        <div><span>Fat</span><strong>${macro.fat}g</strong></div>
      </div>
    </button>
  `;
}

function renderMeals() {
  const root = document.getElementById("mealsList");
  root.classList.add("desktop-grid");
  root.innerHTML = meals.map(mealCard).join("");
}

function renderMealDetails() {
  const item = meals[state.selectedMeal];
  const custom = state.customization[state.selectedMeal] ?? { proteinIndex: item.proteinIndex, carbIndex: item.carbIndex, sauceIndex: item.sauceIndex, size: 150 };
  state.customization[state.selectedMeal] = custom;
  const macro = macrosFor(item, custom);
  document.getElementById("mealDetailsContent").innerHTML = `
    <div class="meal-art" style="min-height:230px;background:linear-gradient(135deg, ${item.colors[0]}, ${item.colors[1]})"><span>🍽</span></div>
    <h2>${item.name}</h2>
    <p class="pill">${macro.calories} calories</p>
    <div class="macro-row">
      <div><span>Protein</span><strong>${macro.protein}g</strong></div>
      <div><span>Carbs</span><strong>${macro.carbs}g</strong></div>
      <div><span>Fat</span><strong>${macro.fat}g</strong></div>
    </div>
    <div class="glass-card">
      ${choiceGroup("Protein", proteins, "proteinIndex", custom.proteinIndex)}
      ${choiceGroup("Protein Size", [100,150,200].map((size) => ({ name: `${size}g`, value: size })), "size", custom.size)}
      ${choiceGroup("Carb", carbs, "carbIndex", custom.carbIndex)}
      ${choiceGroup("Sauce", sauces, "sauceIndex", custom.sauceIndex)}
    </div>
    <div class="choice-grid">${item.ingredients.map((ingredient) => `<span class="chip">${ingredient}</span>`).join("")}</div>
    <button class="primary" data-toast>Add to Plan</button>
  `;
}

function choiceGroup(title, list, key, selected) {
  return `<div class="choice-group"><span class="eyebrow">${title}</span><div class="choice-grid">${list.map((item, index) => {
    const value = item.value ?? index;
    return `<button class="chip ${value === selected ? "selected" : ""}" data-choice="${key}" data-value="${value}">${item.name}</button>`;
  }).join("")}</div></div>`;
}

function renderHome() {
  document.getElementById("todayMeals").innerHTML = meals.slice(0, 3).map((item) => {
    const macro = macrosFor(item);
    return `<div class="today-item"><div class="thumb" style="background:linear-gradient(135deg, ${item.colors[0]}, ${item.colors[1]})">🍽</div><strong>${item.name}</strong><span class="muted">${macro.calories} kcal</span></div>`;
  }).join("");
}

function renderCheckout() {
  const [name, price] = state.selectedPlan ?? plans[0];
  const vat = Math.round(price * 0.15);
  const total = price + vat;
  document.getElementById("checkoutSummary").innerHTML = `
    <div class="glass-card">
      <div class="summary-row"><span>Plan</span><strong>${name}</strong></div>
      <div class="summary-row"><span>Duration</span><strong>Monthly subscription</strong></div>
      <div class="summary-row"><span>Address</span><strong>Riyadh, Saudi Arabia</strong></div>
      <div class="summary-row"><span>Payment</span><strong>Visa ending 4242</strong></div>
    </div>
    <div class="glass-card">
      <div class="summary-row"><span>Plan price</span><strong>${price} SAR</strong></div>
      <div class="summary-row"><span>VAT 15%</span><strong>${vat} SAR</strong></div>
      <div class="summary-row"><span>Delivery</span><strong>Included</strong></div>
      <div class="summary-row"><span>Total</span><strong class="pill">${total} SAR</strong></div>
    </div>
  `;
}

document.addEventListener("click", (event) => {
  const target = event.target.closest("button");
  if (!target) return;
  if (target.dataset.route) route(target.dataset.route);
  if (target.dataset.back !== undefined) back();
  if (target.dataset.tab) route(target.dataset.tab);
  if (target.dataset.goal) { state.goal = target.dataset.goal; renderGoals(); }
  if (target.dataset.count) { state.mealsPerDay = Number(target.dataset.count); renderMealCounts(); }
  if (target.dataset.plan) { state.selectedPlan = plans[Number(target.dataset.plan)]; route("checkout"); }
  if (target.dataset.meal) { state.selectedMeal = Number(target.dataset.meal); renderMealDetails(); route("mealDetails"); }
  if (target.dataset.choice) {
    const custom = state.customization[state.selectedMeal];
    custom[target.dataset.choice] = Number(target.dataset.value);
    renderMealDetails();
  }
  if (target.dataset.toast !== undefined) {
    target.textContent = "Added";
    setTimeout(() => target.textContent = "Add to Plan", 900);
  }
});

renderGoals();
renderMealCounts();
renderMeals();
renderHome();
