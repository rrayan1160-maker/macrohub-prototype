import 'package:flutter/material.dart';

import '../models/mock_data.dart';
import '../models/plan.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_title.dart';
import 'checkout_screen.dart';

class PlansScreen extends StatelessWidget {
  const PlansScreen({
    super.key,
    required this.goal,
    required this.mealsPerDay,
  });

  static const route = '/plans';

  final String goal;
  final int mealsPerDay;

  @override
  Widget build(BuildContext context) {
    final plans = plansForMeals(mealsPerDay);
    return AppShell(
      title: 'Plans',
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionTitle(
              title: 'Pick your plan',
              subtitle: '$goal - $mealsPerDay meals per day - billed monthly in SAR.',
            ),
            const SizedBox(height: 22),
            Expanded(
              child: ListView.separated(
                itemCount: plans.length,
                separatorBuilder: (_, __) => const SizedBox(height: 16),
                itemBuilder: (context, index) => _PlanCard(plan: plans[index]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({required this.plan});

  final MealPlan plan;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  plan.name,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
              ),
              Text(
                '${plan.price} SAR',
                style: const TextStyle(
                  color: AppTheme.turquoise,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(plan.description, style: const TextStyle(color: AppTheme.textMuted, height: 1.4)),
          const SizedBox(height: 14),
          Row(
            children: [
              const Icon(Icons.calendar_month_rounded, size: 18, color: AppTheme.turquoise),
              const SizedBox(width: 8),
              Text('${plan.mealsPerDay} meals daily'),
              const Spacer(),
              TextButton(
                onPressed: () => Navigator.pushNamed(
                  context,
                  CheckoutScreen.route,
                  arguments: plan,
                ),
                child: const Text('Select'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
