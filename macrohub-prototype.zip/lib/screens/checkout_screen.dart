import 'package:flutter/material.dart';

import '../models/plan.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_title.dart';
import 'dashboard_screen.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key, required this.plan});

  static const route = '/checkout';

  final MealPlan plan;

  @override
  Widget build(BuildContext context) {
    const deliveryFee = 0;
    final vat = (plan.price * 0.15).round();
    final total = plan.price + vat + deliveryFee;

    return AppShell(
      title: 'Checkout',
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionTitle(
              title: 'Confirm subscription',
              subtitle: 'Review your MacroHub plan before activating the prototype checkout.',
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  _SummaryTile(title: 'Plan', value: plan.name, icon: Icons.inventory_2_rounded),
                  _SummaryTile(
                    title: 'Duration',
                    value: 'Monthly subscription',
                    icon: Icons.repeat_rounded,
                  ),
                  const _SummaryTile(
                    title: 'Address',
                    value: 'Riyadh, Saudi Arabia',
                    icon: Icons.location_on_rounded,
                  ),
                  const _SummaryTile(
                    title: 'Payment',
                    value: 'Visa ending 4242',
                    icon: Icons.credit_card_rounded,
                  ),
                  const SizedBox(height: 12),
                  GlassCard(
                    child: Column(
                      children: [
                        _PriceRow(label: 'Plan price', value: '${plan.price} SAR'),
                        const SizedBox(height: 10),
                        _PriceRow(label: 'VAT 15%', value: '$vat SAR'),
                        const SizedBox(height: 10),
                        const _PriceRow(label: 'Delivery', value: 'Included'),
                        const Divider(height: 28),
                        _PriceRow(
                          label: 'Total',
                          value: '$total SAR',
                          isTotal: true,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pushNamedAndRemoveUntil(
                context,
                DashboardScreen.route,
                (route) => false,
              ),
              child: const Text('Pay / Confirm Subscription'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryTile extends StatelessWidget {
  const _SummaryTile({
    required this.title,
    required this.value,
    required this.icon,
  });

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        padding: const EdgeInsets.all(16),
        radius: 20,
        child: Row(
          children: [
            Icon(icon, color: AppTheme.turquoise),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                  const SizedBox(height: 3),
                  Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PriceRow extends StatelessWidget {
  const _PriceRow({
    required this.label,
    required this.value,
    this.isTotal = false,
  });

  final String label;
  final String value;
  final bool isTotal;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: TextStyle(
            color: isTotal ? Colors.white : AppTheme.textMuted,
            fontWeight: isTotal ? FontWeight.w900 : FontWeight.w600,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: TextStyle(
            color: isTotal ? AppTheme.turquoise : Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: isTotal ? 20 : 15,
          ),
        ),
      ],
    );
  }
}
