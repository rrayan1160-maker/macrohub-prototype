import 'package:flutter/material.dart';

import '../models/meal.dart';
import '../models/mock_data.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';
import '../widgets/glass_card.dart';
import '../widgets/macro_chip.dart';
import '../widgets/meal_art.dart';

class MealDetailsScreen extends StatefulWidget {
  const MealDetailsScreen({super.key, required this.meal});

  static const route = '/meal-details';

  final Meal meal;

  @override
  State<MealDetailsScreen> createState() => _MealDetailsScreenState();
}

class _MealDetailsScreenState extends State<MealDetailsScreen> {
  late ProteinChoice selectedProtein = widget.meal.defaultProtein;
  late int selectedProteinSize = 150;
  late CarbChoice selectedCarb = widget.meal.defaultCarb;
  late SauceChoice selectedSauce = widget.meal.defaultSauce;

  MacroSet get macros => widget.meal.calculateMacros(
        proteinChoice: selectedProtein,
        proteinSize: selectedProteinSize,
        carbChoice: selectedCarb,
        sauceChoice: selectedSauce,
      );

  @override
  Widget build(BuildContext context) {
    return AppShell(
      title: 'Meal Details',
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ListView(
                children: [
                  Hero(
                    tag: 'meal-${widget.meal.name}',
                    child: MealArt(colors: widget.meal.colors, height: 230, iconSize: 70),
                  ),
                  const SizedBox(height: 22),
                  Text(
                    widget.meal.name,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 10),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 240),
                    child: Text(
                      '${macros.calories} calories',
                      key: ValueKey(macros.calories),
                      style: const TextStyle(
                        color: AppTheme.turquoise,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 240),
                    child: Row(
                      key: ValueKey('${macros.protein}-${macros.carbs}-${macros.fat}'),
                      children: [
                        Expanded(child: MacroChip(label: 'Protein', value: '${macros.protein}g')),
                        const SizedBox(width: 10),
                        Expanded(child: MacroChip(label: 'Carbs', value: '${macros.carbs}g')),
                        const SizedBox(width: 10),
                        Expanded(child: MacroChip(label: 'Fat', value: '${macros.fat}g')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  GlassCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Customize Meal', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 16),
                        _ChoiceSection<ProteinChoice>(
                          title: 'Protein',
                          options: proteinChoices,
                          selected: selectedProtein,
                          label: (item) => item.name,
                          onSelected: (item) => setState(() => selectedProtein = item),
                        ),
                        const SizedBox(height: 16),
                        _ChoiceSection<int>(
                          title: 'Protein Size',
                          options: const [100, 150, 200],
                          selected: selectedProteinSize,
                          label: (item) => '${item}g',
                          onSelected: (item) => setState(() => selectedProteinSize = item),
                        ),
                        const SizedBox(height: 16),
                        _ChoiceSection<CarbChoice>(
                          title: 'Carb',
                          options: carbChoices,
                          selected: selectedCarb,
                          label: (item) => item.name,
                          onSelected: (item) => setState(() => selectedCarb = item),
                        ),
                        const SizedBox(height: 16),
                        _ChoiceSection<SauceChoice>(
                          title: 'Sauce',
                          options: sauceChoices,
                          selected: selectedSauce,
                          label: (item) => item.name,
                          onSelected: (item) => setState(() => selectedSauce = item),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  const Text('Ingredients', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: widget.meal.ingredients
                        .map(
                          (item) => Chip(
                            label: Text(item),
                            backgroundColor: AppTheme.surfaceLight,
                            side: BorderSide(color: Colors.white.withOpacity(0.06)),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${widget.meal.name} added to your plan')),
              ),
              child: const Text('Add to Plan'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChoiceSection<T> extends StatelessWidget {
  const _ChoiceSection({
    required this.title,
    required this.options,
    required this.selected,
    required this.label,
    required this.onSelected,
  });

  final String title;
  final List<T> options;
  final T selected;
  final String Function(T item) label;
  final ValueChanged<T> onSelected;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(color: AppTheme.textMuted, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options.map((item) {
            final isSelected = item == selected;
            return ChoiceChip(
              label: Text(label(item)),
              selected: isSelected,
              onSelected: (_) => onSelected(item),
              selectedColor: AppTheme.turquoise,
              backgroundColor: AppTheme.surfaceLight,
              labelStyle: TextStyle(
                color: isSelected ? const Color(0xFF04252B) : Colors.white,
                fontWeight: FontWeight.w800,
              ),
              side: BorderSide(
                color: isSelected ? AppTheme.turquoise : Colors.white.withOpacity(0.06),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
