class MealPlan {
  const MealPlan({
    required this.name,
    required this.price,
    required this.description,
    required this.mealsPerDay,
  });

  final String name;
  final int price;
  final String description;
  final int mealsPerDay;
}
