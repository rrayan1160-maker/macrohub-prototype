import 'package:flutter/material.dart';

class MacroSet {
  const MacroSet({
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fat,
  });

  final int calories;
  final int protein;
  final int carbs;
  final int fat;
}

class ProteinChoice {
  const ProteinChoice({
    required this.name,
    required this.proteinPer100g,
    required this.fatPer100g,
  });

  final String name;
  final int proteinPer100g;
  final int fatPer100g;
}

class CarbChoice {
  const CarbChoice({
    required this.name,
    required this.carbs,
    required this.calories,
  });

  final String name;
  final int carbs;
  final int calories;
}

class SauceChoice {
  const SauceChoice({
    required this.name,
    required this.calories,
    required this.carbs,
    required this.fat,
  });

  final String name;
  final int calories;
  final int carbs;
  final int fat;
}

class Meal {
  const Meal({
    required this.name,
    required this.baseCalories,
    required this.baseProtein,
    required this.baseCarbs,
    required this.baseFat,
    required this.ingredients,
    required this.colors,
    required this.defaultProtein,
    required this.defaultCarb,
    required this.defaultSauce,
  });

  final String name;
  final int baseCalories;
  final int baseProtein;
  final int baseCarbs;
  final int baseFat;
  final List<String> ingredients;
  final List<Color> colors;
  final ProteinChoice defaultProtein;
  final CarbChoice defaultCarb;
  final SauceChoice defaultSauce;

  int get calories => calculateMacros().calories;
  int get protein => calculateMacros().protein;
  int get carbs => calculateMacros().carbs;
  int get fat => calculateMacros().fat;

  MacroSet calculateMacros({
    ProteinChoice? proteinChoice,
    int proteinSize = 150,
    CarbChoice? carbChoice,
    SauceChoice? sauceChoice,
  }) {
    final selectedProtein = proteinChoice ?? defaultProtein;
    final selectedCarb = carbChoice ?? defaultCarb;
    final selectedSauce = sauceChoice ?? defaultSauce;
    final multiplier = proteinSize / 100;
    final protein = (selectedProtein.proteinPer100g * multiplier).round();
    final proteinFat = (selectedProtein.fatPer100g * multiplier).round();
    final proteinCalories = (protein * 4) + (proteinFat * 9);
    const vegetablesCalories = 55;
    const vegetablesCarbs = 8;
    const vegetablesFat = 1;

    return MacroSet(
      calories: proteinCalories + selectedCarb.calories + selectedSauce.calories + vegetablesCalories,
      protein: protein,
      carbs: selectedCarb.carbs + selectedSauce.carbs + vegetablesCarbs,
      fat: proteinFat + selectedSauce.fat + vegetablesFat,
    );
  }
}
