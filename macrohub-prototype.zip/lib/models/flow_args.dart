import 'package:flutter/widgets.dart';

import '../screens/meals_per_day_screen.dart';
import '../screens/plans_screen.dart';

class GoalSelectionArgs {
  const GoalSelectionArgs(this.goal);

  final String goal;

  static GoalSelectionArgs scope(Object? args) {
    return args is GoalSelectionArgs ? args : const GoalSelectionArgs('Maintain');
  }

  Widget buildMealsPerDay() => MealsPerDayScreen(goal: goal);
}

class MealsPerDayArgs {
  const MealsPerDayArgs({
    required this.goal,
    required this.mealsPerDay,
  });

  final String goal;
  final int mealsPerDay;

  static MealsPerDayArgs scope(Object? args) {
    return args is MealsPerDayArgs
        ? args
        : const MealsPerDayArgs(goal: 'Maintain', mealsPerDay: 3);
  }

  Widget buildPlans() => PlansScreen(goal: goal, mealsPerDay: mealsPerDay);
}
