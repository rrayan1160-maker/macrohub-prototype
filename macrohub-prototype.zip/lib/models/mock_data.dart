import 'package:flutter/material.dart';

import 'meal.dart';
import 'plan.dart';

const proteinChoices = <ProteinChoice>[
  ProteinChoice(name: 'صدر دجاج', proteinPer100g: 31, fatPer100g: 4),
  ProteinChoice(name: 'لحم قليل الدهون', proteinPer100g: 27, fatPer100g: 9),
  ProteinChoice(name: 'Kofta', proteinPer100g: 24, fatPer100g: 12),
  ProteinChoice(name: 'Greek Yogurt Protein', proteinPer100g: 18, fatPer100g: 3),
];

const carbChoices = <CarbChoice>[
  CarbChoice(name: 'رز أبيض', carbs: 42, calories: 190),
  CarbChoice(name: 'رز بني', carbs: 38, calories: 180),
  CarbChoice(name: 'بطاطس', carbs: 34, calories: 155),
  CarbChoice(name: 'مكرونة', carbs: 46, calories: 220),
];

const sauceChoices = <SauceChoice>[
  SauceChoice(name: 'صوص ريحان', calories: 45, carbs: 2, fat: 4),
  SauceChoice(name: 'ليمون وفلفل', calories: 35, carbs: 4, fat: 1),
  SauceChoice(name: 'سموكي BBQ', calories: 60, carbs: 8, fat: 2),
  SauceChoice(name: 'ترياكي', calories: 70, carbs: 12, fat: 1),
  SauceChoice(name: 'صوص مشروم', calories: 65, carbs: 5, fat: 4),
  SauceChoice(name: 'داود باشا طماطم', calories: 55, carbs: 7, fat: 2),
  SauceChoice(name: 'Honey Berry', calories: 50, carbs: 10, fat: 0),
  SauceChoice(name: 'Cinnamon Protein', calories: 40, carbs: 5, fat: 1),
];

const meals = <Meal>[
  Meal(
    name: 'دجاج ريحان',
    baseCalories: 510,
    baseProtein: 46,
    baseCarbs: 52,
    baseFat: 11,
    ingredients: ['Chicken breast', 'Basil sauce', 'Rice', 'Zucchini'],
    colors: [Color(0xFF2DD4BF), Color(0xFF0F766E)],
    defaultProtein: proteinChoices[0],
    defaultCarb: carbChoices[0],
    defaultSauce: sauceChoices[0],
  ),
  Meal(
    name: 'دجاج ليمون وفلفل',
    baseCalories: 485,
    baseProtein: 47,
    baseCarbs: 42,
    baseFat: 9,
    ingredients: ['Chicken breast', 'Lemon pepper', 'Potato', 'Broccoli'],
    colors: [Color(0xFFFACC15), Color(0xFF16A34A)],
    defaultProtein: proteinChoices[0],
    defaultCarb: carbChoices[2],
    defaultSauce: sauceChoices[1],
  ),
  Meal(
    name: 'لحم سموكي',
    baseCalories: 620,
    baseProtein: 42,
    baseCarbs: 56,
    baseFat: 20,
    ingredients: ['Lean beef', 'Smoky BBQ sauce', 'Brown rice', 'Green beans'],
    colors: [Color(0xFFFB923C), Color(0xFF7F1D1D)],
    defaultProtein: proteinChoices[1],
    defaultCarb: carbChoices[1],
    defaultSauce: sauceChoices[2],
  ),
  Meal(
    name: 'كفتة داود باشا',
    baseCalories: 650,
    baseProtein: 39,
    baseCarbs: 50,
    baseFat: 24,
    ingredients: ['Kofta', 'Tomato sauce', 'White rice', 'Parsley'],
    colors: [Color(0xFFEF4444), Color(0xFF7C2D12)],
    defaultProtein: proteinChoices[2],
    defaultCarb: carbChoices[0],
    defaultSauce: sauceChoices[5],
  ),
  Meal(
    name: 'دجاج ترياكي',
    baseCalories: 540,
    baseProtein: 45,
    baseCarbs: 58,
    baseFat: 10,
    ingredients: ['Chicken breast', 'Teriyaki sauce', 'Rice', 'Sesame vegetables'],
    colors: [Color(0xFF38BDF8), Color(0xFF1E3A8A)],
    defaultProtein: proteinChoices[0],
    defaultCarb: carbChoices[0],
    defaultSauce: sauceChoices[3],
  ),
  Meal(
    name: 'دجاج مشروم',
    baseCalories: 525,
    baseProtein: 46,
    baseCarbs: 44,
    baseFat: 15,
    ingredients: ['Chicken breast', 'Mushroom sauce', 'Pasta', 'Spinach'],
    colors: [Color(0xFFA3E635), Color(0xFF365314)],
    defaultProtein: proteinChoices[0],
    defaultCarb: carbChoices[3],
    defaultSauce: sauceChoices[4],
  ),
  Meal(
    name: 'Greek Yogurt Bowl',
    baseCalories: 390,
    baseProtein: 31,
    baseCarbs: 44,
    baseFat: 9,
    ingredients: ['Greek yogurt', 'Granola', 'Berries', 'Honey drizzle'],
    colors: [Color(0xFF60A5FA), Color(0xFF9333EA)],
    defaultProtein: proteinChoices[3],
    defaultCarb: carbChoices[1],
    defaultSauce: sauceChoices[6],
  ),
  Meal(
    name: 'Protein Oats',
    baseCalories: 430,
    baseProtein: 35,
    baseCarbs: 48,
    baseFat: 10,
    ingredients: ['Protein oats', 'Greek yogurt', 'Banana', 'Cinnamon'],
    colors: [Color(0xFFFDE68A), Color(0xFF92400E)],
    defaultProtein: proteinChoices[3],
    defaultCarb: carbChoices[3],
    defaultSauce: sauceChoices[7],
  ),
];

List<MealPlan> plansForMeals(int mealsPerDay) {
  return [
    MealPlan(
      name: 'Balanced Plan',
      price: 899,
      description: 'A complete mix of protein, clean carbs, and healthy fats.',
      mealsPerDay: mealsPerDay,
    ),
    MealPlan(
      name: 'High Protein Plan',
      price: 1049,
      description: 'Higher protein meals for active routines and recovery.',
      mealsPerDay: mealsPerDay,
    ),
    MealPlan(
      name: 'Low Carb Plan',
      price: 969,
      description: 'Lighter carb portions with high-satiety ingredients.',
      mealsPerDay: mealsPerDay,
    ),
    MealPlan(
      name: 'Custom Macros',
      price: 1199,
      description: 'Macro targets tuned to your nutrition preferences.',
      mealsPerDay: mealsPerDay,
    ),
  ];
}
